<?php
include 'koneksi.php';
$query1 = mysqli_query($conn, "SELECT COUNT(id_pemesanan) AS jumlah_pemesan FROM tb_pemesanan WHERE status_pemesan='Datang'");
$query2 = mysqli_query($conn, "SELECT SUM(tb_beli.jumlah_tiket) AS jumlah_tiket FROM tb_beli INNER JOIN tb_pemesanan ON tb_pemesanan.id_pemesanan = tb_beli.id_pemesan WHERE tb_beli.kategori_tiket='1' AND tb_pemesanan.status_pemesan='Datang'");
$query3 = mysqli_query($conn, "SELECT SUM(tb_beli.jumlah_tiket) AS jumlah_tiket FROM tb_beli INNER JOIN tb_pemesanan ON tb_pemesanan.id_pemesanan = tb_beli.id_pemesan WHERE tb_beli.kategori_tiket='2' AND tb_pemesanan.status_pemesan='Datang'");
//$query4 = mysqli_query($conn, "SELECT SUM(jumlah_tiket) AS jumlah_tiket FROM tb_beli WHERE kategori_tiket='1'");

if(mysqli_num_rows($query1) > 0) {
    $dataJumlah = mysqli_fetch_array($query1);
    $data_jumlah= (int)$dataJumlah[0];
}
if(mysqli_num_rows($query2) > 0) {
    $dataDewasa = mysqli_fetch_array($query2);
    $dataDewasa = (int)$dataDewasa[0];
    //var_dump($dataDewasa); die;
    //$dataDewasa= (int)$dataDewasa[0];
}
if(mysqli_num_rows($query3) > 0) {
    $dataAnak = mysqli_fetch_array($query3);
    $dataAnak= (int)$dataAnak[0];
}
//$data = mysqli_fetch_array($query4);
//$jml_anak = $data["jumlah_tiket"];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Museum Trinil</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="<link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body>
    <!--header-->
   
<!-- content-->
<div>
    <div class="section">
        <div class="container">
            <h1>Dashboard</h1>
            <div class="">
                <h4>Selamat Datang <?php if (isset($_SESSION['a_global'])){ echo $_SESSION['a_global']->nama_admin; }?> di Museum Trinil</h4>
            </div>
            <main>
                <div class="cards">
                   
                    <div class="card-single">
                        <div>
                            <h1><?php echo number_format($data_jumlah,0,",",","); ?></h1>
                            <span>Data Pemesan Berstatus Datang</span>
                        </div>
                        <div>
                            <span class="las la-users"></span>
                        </div>
                    </div>

                    <div class="card-single">
                        <div>
                            <h1><?php echo number_format($dataDewasa,0,",",","); ?></h1>
                            <span>Jumlah Tiket Dewasa Berstatus Datang</span>
                        </div>
                        <div>
                            <span class="las la-tasks"></span>
                        </div>
                    </div>

                    <div class="card-single">
                        <div>
                            <h1><?php echo number_format($dataAnak,0,",",","); ?></h1>
                            <span>Jumlah Tiket Anak-anak Berstatus Datang</span>
                        </div>
                        <div>
                            <span class="las la-file-alt"></span>
                        </div>
                    </div>

                    <!--<div class="card-single">
                        <div>
                            <h1><?php echo number_format($jml_anak,0,",",","); ?></h1>
                            <span>Tiket Kategori Anak yang Terjual</span>
                        </div>
                        <div>
                            <span class="las la-th-list"></span>
                        </div>
                    </div>-->

                   

                    
                </div>
            </main>
</div>
</div>

<!--footer-->

</body>
</html>
<?php include("koneksi.php") ;

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Museum Trinil</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.12.0/datatables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.0/datatables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
</head>
<body>
    <!--header-->
  
<!-- content-->
<div>
    <div class="section">
        <div class="container">
        <div class="card-tools">
        <a href="?page=datapemesan" class="btn btn-sm btn-warning float-right"><i class="fas fa-arrow-alt-circle-left"></i> Kembali</a>
        </div>
            <h1>Detail Pemesanan Tiket</h1>
            <div class="">
                </form>
                <table border="1" cellspacing="0" id="datatabel" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th width = "60px">No</th>
                            <!-- <th>Id Pembelian</th> -->
                            <th>Id Pemesan</th>
                            <th>Nama Pemesan</th>
                            <th>Tanggal</th>
                            <th>Kategori Tiket</th>
                            <th >Jumlah Tiket</th>
                            <!--<th>Total Harga</th>-->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $id = $_GET['idk'];
                        $beli = mysqli_query($conn, "SELECT tb_beli.*, tb_pemesanan.*, tb_tiket.kategori_tiket, tb_pemesanan.nama_pemesan 
                        FROM `tb_beli` JOIN tb_pemesanan ON tb_beli.id_pemesan = tb_pemesanan.id_pemesanan LEFT JOIN tb_tiket ON tb_beli.kategori_tiket = tb_tiket.id_tiket WHERE id_pemesanan=$id");
                        
                        if(mysqli_num_rows($beli) > 0){
                            WHILE($row = mysqli_fetch_array($beli)){
                        ?>
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row['id_pemesan'] ?></td>
                            <td><?php echo $row['nama_pemesan'] ?></td>
                            <td><?php echo $row['tanggal'] ?></td>
                            <td><?php echo $row['kategori_tiket'] ?></td>
                            <td class="text-center"><?php echo $row['jumlah_tiket'] ?></td>
                            <!--<td><?php echo $row['total_harga'] ?></td>-->
                           
                            <!-- <td><?php echo $row['id_pemesan'] ?></td> -->
                            
                        </tr>
                        <?php }}else{ ?>
                            <tr>
                            <td colspan="3">Tidak ada Produk</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
</div>
</div>
</div>
<!--footer-->
<script>
    $(document).ready( function () {
        $('#datatabel').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'excel'
            ]
        });
    });
</script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
</body>
</html>
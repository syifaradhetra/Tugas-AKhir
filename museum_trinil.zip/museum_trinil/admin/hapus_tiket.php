<?php
include 'koneksi.php';

if(isset($_GET['idk'])){
    $delete = mysqli_query($conn, "UPDATE tb_tiket SET deleted=1 WHERE id_tiket = '".$_GET['idk']."' ");
    echo '<script>window.location="?page=datatiket"</script>';
}
?>
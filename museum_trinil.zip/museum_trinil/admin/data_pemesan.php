<?php include("koneksi.php");
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Museum Trinil</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.12.0/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.0/datatables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">

</head>
<body>
    <!--header-->
  
<!-- content-->
<div>
    <div class="section">
        <div class="container">
            <h1>Data Pemesan</h1>
            <!--<div class="">
                <form method="post" action="">
                <div class="row">
                    <div class="col-md-4">
                    <input type="text" name="katakunci" placeholder="Cari Data"/>
                    </div>
                    
                    <button type="submit" class="btn btn-danger btn-s text-white"><i class="fa fa-search"></i> Search</button>
                    
                </form>
                </div>-->
                
                
                <td class="text-center">
                            <a class="btn btn-info btn-s text-white" href="?page=datapemesan&status=Datang">Status Datang</a><br>
                          </td><br>
                <table border="1" cellspacing="0" id="datatabel" class="table table-striped table-bordered">
                
                    <thead>
                        <tr>
                            <th width = "60px">No</th>
                            <th>Nama</th>
                            <th>No KTP</th>
                            <th>No HP</th>
                            <th>Alamat</th>
                            <th>Tanggal</th>
                            <th>Total Harga</th>
                            <th>Jenis Bank</th>
                            <th>Bukti Transfer</th>
                            <th>Status</th>
                            <th class="text-center" width = "150px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $status = isset($_GET['status']) ? $_GET['status'] : "";
                        //$katakunci = $_POST['katakunci'];
                        if($status != ''){
                            $pemesanan = mysqli_query($conn, "SELECT tb_bukti.*, tb_rekening.jenis_rek as rek, tb_pemesanan.nama_pemesan as nama_pemesan, tb_pemesanan.no_ktp as no_ktp, tb_pemesanan.no_hp as no_hp, tb_pemesanan.alamat as alamat, tb_pemesanan.tanggal as tanggal, tb_pemesanan.total_harga as total_harga, tb_bukti.bukti_tf as bukti_tf, tb_pemesanan.status_pemesan as status_pemesan FROM tb_pemesanan JOIN tb_rekening ON tb_pemesanan.jenis_rek = tb_rekening.id_rek JOIN tb_bukti ON tb_pemesanan.id_pemesanan = tb_bukti.id_pemesanan WHERE tb_pemesanan.status_pemesan='Datang'");
                        }else{
                            $pemesanan = mysqli_query($conn, "SELECT tb_bukti.*, tb_rekening.jenis_rek as rek, tb_pemesanan.nama_pemesan as nama_pemesan, tb_pemesanan.no_ktp as no_ktp, tb_pemesanan.no_hp as no_hp, tb_pemesanan.alamat as alamat, tb_pemesanan.tanggal as tanggal, tb_pemesanan.total_harga as total_harga, tb_bukti.bukti_tf as bukti_tf, tb_pemesanan.status_pemesan as status_pemesan FROM tb_pemesanan JOIN tb_rekening ON tb_pemesanan.jenis_rek = tb_rekening.id_rek JOIN tb_bukti ON tb_pemesanan.id_pemesanan = tb_bukti.id_pemesanan ORDER BY id_pemesanan DESC");
                        }
                        
                        if(mysqli_num_rows($pemesanan) > 0){
                        WHILE($row = mysqli_fetch_array($pemesanan)){
                            //var_dump($row); die;
                        ?>
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row['nama_pemesan'] ?></td>
                            <td><?php echo $row['no_ktp'] ?></td>
                            <td><?php echo $row['no_hp'] ?></td>
                            <td><?php echo $row['alamat'] ?></td>
                            <td><?php echo $row['tanggal'] ?></td>
                            <td><?php echo $row['total_harga'] ?></td>
                            <td><?php echo $row['rek'] ?></td>
                            <td class="text-center"><a href="../html/terupload/<?php echo $row['bukti_tf'] ?>" target="_blank"><img src="../html/terupload/<?php echo $row['bukti_tf'] ?>"width="80px"></a><?php echo $row['bukti_tf'] ?></td>
                            
                            <td class="text-center" width = "150px"><?php echo $row['status_pemesan'] ?></td>
                            
                            <td class="text-center">
                            <a class="btn btn-info btn-s text-white" href="?page=detailpemesanan&idk=<?= $row['id_pemesanan'] ?>" ><i class="fa fa-eye"></i></a><br>
                            <a class="btn btn-info btn-s text-white" href="?page=editpemesanan&id=<?= $row['id_pemesanan'] ?>"><i class="fa fa-edit"></i></a>
                          </a></td>
                        </tr>
                        <?php }}else{ ?>
                            <tr>
                            <td colspan="3">Tidak ada Produk</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <br><br>
                
</div>
</div>
</div>
<!--footer-->

<script>
    $(document).ready( function () {
        $('#datatabel').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'excel'
            ]
        });
        
    });
</script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> -->

</body>
</html>
<?php
include 'koneksi.php';
    $pesan = mysqli_query($conn, "SELECT * FROM tb_pemesanan WHERE id_pemesanan = '".$_GET['id']."' ");
    $p = mysqli_fetch_object($pesan);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Museum Trinil</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body>
    <!--header-->
   
<!-- content-->
<div>
    <div class="section">
        <div class="container">
            <h1>Edit Status Pemesan</h1>
            
            <div class="box">
            <div class="card-tools">
                <a href="?page=datapemesan" class="btn btn-sm btn-warning float-right"><i class="fas fa-arrow-alt-circle-left"></i> Kembali</a>
            </div>
            <form action="" method="POST">
                <input type="text" name="nama_pemesan" placeholder="Nama Pemesan" class="input-control" readonly
                value="<?php echo $p -> nama_pemesan ?>" required>
                <!--<input type="text" name="no_ktp" placeholder="No KTP" class="input-control" 
                value="<?php echo $p -> no_ktp ?>" required>
                <input type="text" name="no_hp" placeholder="No HP" class="input-control" 
                value="<?php echo $p -> no_hp ?>" required>
                <input type="text" name="alamat" placeholder="Alamat" class="input-control" 
                value="<?php echo $p -> alamat ?>" required>-->
                <input type="text" name="tanggal" placeholder="Tanggal" class="input-control" readonly
                value="<?php echo $p -> tanggal ?>" required>
                <input type="text" name="total_harga" placeholder="Total Harga" class="input-control" readonly
                value="<?php echo $p -> total_harga ?>" required>
                <!--<input type="text" name="jenis_rek" placeholder="Jenis Bank" class="input-control" 
                value="<?php echo $p -> jenis_rek ?>" required><br>-->

                                <select class="input-control" name="status_pemesan" required>

                                <option value="Pesan" >Pesan</option>
                                <option value="Datang" >Datang</option>
                                </select><br>
                <input type="submit" name="submit" value="Tambah" class="btn">
            </form>
            <?php
            if(isset($_POST['submit'])){
                $nama_pemesan = ucwords($_POST['nama_pemesan']);
                //$no_ktp = ucwords($_POST['no_ktp']);
                //$no_hp = ucwords($_POST['no_hp']);
                //$alamat = ucwords($_POST['alamat']);
                $tanggal = ucwords($_POST['tanggal']);
                $total_harga = ucwords($_POST['total_harga']);
                //$jenis_rek = ucwords($_POST['jenis_rek']);
                $status_pemesan = ucwords($_POST['status_pemesan']);

                $update = mysqli_query($conn, "UPDATE tb_pemesanan SET
                status_pemesan = '".$status_pemesan."'
                WHERE id_pemesanan = '".$p->id_pemesanan."' ");


                if($update){
                    echo '<script>alert("Edit data berhasil")</script>';
                    echo '<script>window.location="?page=datapemesan"</script>';
                }else{
                    echo 'Gagal' .mysqli_error($conn);
                }
            }
            ?>
</div>
</div>
</div>
</div>
<!--footer-->

</body>
</html>
<?php include("koneksi.php") ;

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Museum Trinil</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body>
    <!--header-->
  
<!-- content-->
<div>
    <div class="section">
        <div class="container">
        <div class="card-tools">
        <a href="?page=databelitiket" class="btn btn-sm btn-warning float-right"><i class="fas fa-arrow-alt-circle-left"></i> Kembali</a>
        </div>
            <h1>Detail Data Pemesan</h1>
            <div class="">
                </form>
                <table border="1" cellspacing="0" id="datatabel" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th width = "60px">No</th>
                            <!-- <th>Id Pembelian</th> -->
                            <th>id pemesan</th>
                            <th>Nama Pemesan</th>
                            <th>No KTP</th>
                            <th>No HP</th>
                            <th>Alamat</th>
                            <th>Tanggal</th>
                            <th>Total Harga</th>
                            <th>Jenis Bank</th>
                            <th>Bukti Transfer</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $id = $_GET['idk'];
                        $pemesanan = mysqli_query($conn, "SELECT tb_pemesanan.*, tb_beli.*, tb_bukti.*, tb_rekening.jenis_rek, tb_beli.kategori_tiket, tb_bukti.bukti_tf 
                        FROM `tb_pemesanan` JOIN tb_beli ON tb_pemesanan.id_pemesanan = tb_beli.id_pemesan LEFT JOIN tb_rekening ON tb_pemesanan.jenis_rek = tb_rekening.id_rek JOIN tb_bukti ON tb_pemesanan.id_pemesanan = tb_bukti.id_pemesanan WHERE id_beli=$id");
                        
                        if(mysqli_num_rows($pemesanan) > 0){
                            WHILE($row = mysqli_fetch_array($pemesanan)){
                        ?>
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row['id_pemesan'] ?></td>
                            <td><?php echo $row['nama_pemesan'] ?></td>
                            <td><?php echo $row['no_ktp'] ?></td>
                            <td><?php echo $row['no_hp'] ?></td>
                            <td><?php echo $row['alamat'] ?></td>
                            <td><?php echo $row['tanggal'] ?></td>
                            <td><?php echo $row['total_harga'] ?></td>
                            <td><?php echo $row['jenis_rek'] ?></td>
                            <td class="text-center"><a href="../html/terupload/<?php echo $row['bukti_tf'] ?>" target="_blank"><img src="../html/terupload/<?php echo $row['bukti_tf'] ?>"width="80px"></a><?php echo $row['bukti_tf'] ?></td>
                            
                            <td><?php echo $row['status_pemesan'] ?></td>
                           
                            <!-- <td><?php echo $row['id_pemesan'] ?></td> -->
                            
                        </tr>
                        <?php }}else{ ?>
                            <tr>
                            <td colspan="3">Tidak ada Produk</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
</div>
</div>
</div>
<!--footer-->

</body>
</html>
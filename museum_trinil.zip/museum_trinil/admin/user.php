<?php include("koneksi.php") ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Museum Trinil</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body>
    <!--header-->
  
<!-- content-->
<div>
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <div class="section">
    <div class="container">
            <!--<div class="card">
              <div class="card-header">-->
                
                <div class="card-tools">
                <h1 class="card-title" style="margin-top:5px;">Daftar User</h1>
                  <a href="?page=tambahuser" class="btn btn-sm btn-info float-right"><i class="fa fa-plus"></i> Tambah User</a>
                </div><br>
              <!-- /.card-header -->
              
              <!-- <div class="col-sm-12">
                  <div class="alert alert-success" role="alert">Data Berhasil Ditambahkan</div>
                  <div class="alert alert-success" role="alert">Data Berhasil Diubah</div>
              </div> -->
              <table id="datatabel" cellspacing="0" class="table table-striped table-bordered">
                  <thead>
                      <tr>
                          <th class="text-center">No</th>
                          <th class="text-center">Nama</th>
                          <th class="text-center">Username</th>
                          <th class="text-center">Foto</th>
                          <th class="text-center">Jabatan</th>
                          <th class="text-center">Telpon</th>
                          <th class="text-center">Email</th>
                          <th class="text-center">Alamat</th>
                          <th class="text-center" width = "150px">Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                  
                  <?php
                    $no = 1;
                    $datas = mysqli_query($conn, "SELECT * FROM tb_admin ORDER BY `id_admin` DESC");
                    if(mysqli_num_rows($datas) > 0){
                      WHILE($data = mysqli_fetch_array($datas)){
                    
                  ?>
                      <tr>
                          <td class="text-center"><?= $no++; ?></td>
                          <td class="text-center"><?= $data['nama_admin'] ?></td>
                          <td class="text-center"><?= $data['username'] ?></td>
                          <td class="text-center"> <img src="img/<?= $data['foto'] ?>" alt="" srcset="" width="80px"> </td>
                          <td class="text-center"><?= $data['jabatan'] ?></td>
                          <td class="text-center"><?= $data['no_telp'] ?></td>
                          <td class="text-center"><?= $data['email'] ?></td>
                          <td class="text-center"><?= $data['alamat'] ?></td>
                          
                          <td class="text-center">
                              <a class="btn btn-info btn-s text-white" href="?page=edituser&id=<?= $data['id_admin'] ?>"><i class="fa fa-edit"></i></a>
                              <a class="btn btn-danger btn-s text-white" href="?page=hapususer&idu=<?= $data['id_admin'] ?>" onclick="return confirm('Yakin Ingin Menghapus ?')"><i class="fa fa-trash"></i></a>
                          </a></td>
                      </tr>
                  <?php }} ?>
                    
                  </tbody>
              </table>
            </div>
            </div>
            
    </body>
</html>
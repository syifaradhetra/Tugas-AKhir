<?php
include 'koneksi.php';

if(isset($_GET['idk'])){
    $delete = mysqli_query($conn, "UPDATE tb_rekening SET deleted=1 WHERE id_rek = '".$_GET['idk']."' ");
    echo '<script>window.location="?page=datatabungan"</script>';
}
?>
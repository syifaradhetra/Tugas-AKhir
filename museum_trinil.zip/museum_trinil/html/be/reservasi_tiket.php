<?php
include("../koneksi.php");

session_start();
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $no_ktp = $_POST['no_ktp'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $tanggal = $_POST['tanggal'];
    $total = $_POST['total'];
    $tabungan = $_POST['tabungan'];
    //$bukti_tf = $_POST['bukti_tf'];
    $status_pemesan = $_POST['status_pemesan'];
    $_SESSION['no_ktp'] = $no_ktp;
    
    
  
      $insert = mysqli_query($conn, "INSERT INTO tb_pemesanan VALUES (
                       null, 
                       '" . $nama . "',
                       '" . $no_ktp . "',
                       '" . $no_hp . "',
                       '" . $alamat . "',
                       '" . $tanggal . "',
                       '" . $total . "',
                       '" . $tabungan . "',
                       '". $status_pemesan . "'
                       ) ");
  
      if ($insert) {
        // echo '<script>alert("Data anda sudah tersimpan")</script>';
        echo '<script>window.location="../reservasi.php"</script>';
      } else {
        echo 'Gagal' . mysqli_error($conn);
      }
    //}
  }
<?php
session_start();
// session_destroy();

include("koneksi.php");
$data = null;
if (isset($_GET['id'])) {
  $pemesan = "SELECT * FROM tb_pemesanan LEFT JOIN tb_rekening ON tb_pemesanan.jenis_rek = tb_rekening.id_rek
  WHERE tb_pemesanan.id_pemesanan='" . $_GET['id'] . "'";
  $result = mysqli_query($conn, $pemesan);
  while ($dataPemesan = mysqli_fetch_assoc($result)) {
    $data = $dataPemesan;
  }

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="copyright" content="MACode ID, https://macodeid.com/">

  <title>Museum Trinil</title>

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/fancybox/css/jquery.fancybox.css">

  <link rel="stylesheet" href="../assets/css/theme.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>

<body>
  <main>
    <div class="page-section">
      <div class="container">
        <div class="text-center">
          <h2 class="title-section mb-3">Bukti Reservasi Tiket</h2>

        </div>


        <div class="row justify-content-center mt-5">
          <div class="col-lg-8">
            <form action="be/reservasi_tiket.php" class="form-contact" enctype="multipart/form-data" method="POST">
              <div class="row">
                <div class="col-12 py-2">
                  <label for="nama" class="fg-grey">Nama</label>
                  <input type="text" name="nama" readonly value="<?php echo ($data != null) ? $data["nama_pemesan"] : ''; ?>" placeholder="Enter name.." class="form-control" required>
                </div>
                <div class="col-12 py-2">
                  <label for="no hp" class="fg-grey">No HP</label>
                  <input type="text" name="no_hp" readonly value="<?php echo ($data != null) ? $data["no_hp"] : ''; ?>" placeholder="No HP.." class="form-control" required>
                </div>

                <div class="col-sm-6 py-2">
                  <label for="tanggal" class="fg-grey">Tanggal</label>
                  <input type="date" name="tanggal" readonly value="<?php echo ($data != null) ? $data["tanggal"] : ''; ?>" placeholder="" class="form-control" required>
                </div>
                <div class="col-sm-6 py-2">
                  <label for="total tiket" class="fg-grey">Total</label>
                  <input type="combo-box" id="totalHarga" readonly value="<?php echo ($data != null) ? $data["total_harga"] : ''; ?>" name="total" placeholder="" class="form-control">
                </div>
                <div class="col-sm-6 py-2">
                  <label for="total tiket" class="fg-grey">Jenis Rekening</label>
                  <input type="combo-box" id="rekening" readonly value="<?php echo ($data != null) ? $data["jenis_rek"] : ''; ?>" name="rekening" placeholder="" class="form-control">
                </div>
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">No</th>
                      <th scope="col">Nama Pemesan</th>
                      <th scope="col">Kategori Tiket</th>
                      <th scope="col">Jumlah</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                        $no = 1;
                        if(isset($_GET['id'])) {
                          $idPemesanan = $_GET['id'];

                        }
                        $beli = mysqli_query($conn, "SELECT tb_beli.*, tb_pemesanan.*, tb_tiket.kategori_tiket, 
                        tb_pemesanan.nama_pemesan FROM tb_beli JOIN tb_pemesanan ON tb_beli.id_pemesan = 
                        tb_pemesanan.id_pemesanan LEFT JOIN tb_tiket ON tb_beli.kategori_tiket = tb_tiket.id_tiket 
                        WHERE id_pemesanan=$idPemesanan");
                        
                        if(mysqli_num_rows($beli) > 0){
                            WHILE($row = mysqli_fetch_array($beli)){
                        ?>
                        <tr>
                            <td><?php echo $no++ ?></td>
                            <td><?php echo $row['nama_pemesan'] ?></td>
                            <td><?php echo $row['kategori_tiket'] ?></td>
                            <td><?php echo $row['jumlah_tiket'] ?></td>
                        </tr>
                            <?php }}else{ ?>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>

  </main>
  <script>
		window.print();
	</script>
</body>

</html>